files
-sample.bm		| test benchmark for hw2
-sample_X.png	| top view of the output magic file
-sample_x.png	| expanded view of the output magic file
-sample.log	| execution and sample solution statistics
-readme.txt	| readme file

